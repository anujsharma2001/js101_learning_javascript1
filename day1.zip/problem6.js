// data can be anything ?
// what if I want to store a name or any other data except number.

// string--- ""

let a= 10; // data is number;

let name= "goku"; // data is string;

console.log(name);