// why do we have three ways of declaring a variable.

const adharcardnumber= 12345;

console.log(adharcardnumber);

