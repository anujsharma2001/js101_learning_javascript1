let Y=10;

let y= 34;

console.log(Y);