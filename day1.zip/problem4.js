// decalaring a variable name using let word.

// they are other 2 way of declaring a variable.


// var , const.

var a= 10; // declaring a variable with name a and assigning a value 10;
console.log(a);


const b= 20; // declaring a variable with name b and assigning a value 10;
console.log(b);