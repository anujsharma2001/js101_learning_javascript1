let a=23;

console.log(a);



// javascript is case senstitive language.