let number= 100;

console.log(number); //number= 100;

number= 12345;

console.log(number); // number= 12345;