

let age= 24; // data is number;

let number= "24"; // data is string;



// in order to check what is the data type inside the varialbe.

console.log(typeof(age));

console.log(typeof(number));