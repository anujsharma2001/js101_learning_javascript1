// 1. create a varialbe with let and assign a value to it .
// output.
let x= 432;
console.log(x);

//2. create another variable with const and assign a value to it.

const name= "luffy";
console.log(typeof(name));

// what is the datatype of const variable.