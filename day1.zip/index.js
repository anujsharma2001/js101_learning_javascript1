// 1st way
let x= 10; // decalring a variable and assigning a value 10 to it.

console.log(x);


//2nd way.
let a; // declaring a variable a
a=20; // assigning a value 20 to the variable.

console.log(a); // printing the variable.
